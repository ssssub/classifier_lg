# LG 냉장고 온라인 상담 매니저

베스트샵 매니저가 매장에서 질문하며 딱 맞는 냉장고를 골라주는 경험을, 웹에서 그대로 재현한 상담형 추천 앱입니다.
설계해 둔 분류 트리(설치형태 → 가구원수·요리습관 → 용량 → 도어방식 → 추가기능 → 결과)를 그대로 따라가되,
후보가 하나로 좁혀지면 남은 질문은 알아서 건너뜁니다.

## 파일 구성

| 파일 | 역할 |
|---|---|
| `app.py` | Streamlit UI — 매니저 대화 흐름, 결과 카드 |
| `engine.py` | 상담 로직 — 질문 순서, 하드 필터, 추가기능 +1점 채점 |
| `data_loader.py` | 엑셀 DB를 엔진이 쓰기 좋은 형태로 정규화 |
| `LG_냉장고_대표상품기준_통합DB.xlsx` | 제품 데이터 84종 (이게 진짜 소스) |
| `requirements.txt`, `.replit` | Replit 실행 설정 |

## Replit에서 실행하기

1. replit.com → **Create Repl → Import / Blank (Python)** 에 이 폴더의 파일을 전부 업로드
   (`.replit` 파일까지 포함해서. 안 보이면 좌측 파일창의 점 세 개 → *Show hidden files*)
2. Shell 탭에서 한 번:
   ```
   pip install -r requirements.txt
   ```
3. 상단의 **Run** 버튼 클릭 → 우측 Webview에 앱이 뜹니다.
4. 외부 공유는 **Deploy**(Autoscale/Static 아님, **Reserved VM** 또는 **Autoscale**) 사용.

> 엑셀 파일명이 바뀌면 `data_loader.py`의 `DATA_FILE` 한 줄만 고치면 됩니다.

## 흐름 (설계 트리 → 코드 대응)

- **Q1 설치형태** → `INSTALL_OPTS`, `filter_candidates`의 설치타입 필터
- **Q2 가구원수 + 요리습관** → `HOUSEHOLD_OPTS` × `COOKING_OPTS` → `LIFESTYLE_TIER` 표로 목표 용량 결정
- **Q2-1 도어방식(800L+ 한정)** → `needs_door_style()`가 필요할 때만 노출 (양문형 / 4도어 / 4도어 AI)
- **Q3 설치공간(폭)** → `needs_space()`가 후보를 실제로 가를 때만 노출
- **Q4 추가기능** → `available_soft_features()` (후보가 가진 기능만 보여줌), 선택분 +1점
- **결과** → `score_and_rank()` 동점 시 에너지등급↑ → 가격↓ 순

## 자주 고치는 부분

- **질문 문구**: `app.py`의 각 `manager(...)` 문장
- **용량 매핑 바꾸기**: `engine.py`의 `LIFESTYLE_TIER` 딕셔너리
- **추가기능 목록**: `data_loader.py`의 `SOFT_FEATURES`
- **동점 정렬 기준**: `engine.py`의 `score_and_rank()` 정렬 키

## 알아두면 좋은 점

- 설계 트리에는 프리스탠딩이 68개로 적혀 있는데 실제 DB엔 **70개**입니다. 데이터 기준으로 동작하니
  트리 다이어그램의 숫자만 나중에 맞춰주면 됩니다.
- "AI 있음/없음" 판정은 제품명·주요기능에 'AI'가 있는지로 잡습니다 (800L+ 4도어 기준 AI 31 / 비AI 11).
- 빌트인(4종)은 모두 용량대가 비슷해 트리 설계대로 용량 질문을 건너뜁니다.
